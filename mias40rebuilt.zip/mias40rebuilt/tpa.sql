use database mias22

Create table is not exists tpa (idx int, patientId text, testId text, fn text, areaTotal real, meanArea real, medArea real, totInt real, meanInt real, medInt real, tumorIdx realareaTotal2 real, meanArea2 real, medArea2 real, totInt2 real, meanInt2 real, medInt2 real, tumorIdx2 real);
insert into tpa(idx, fn, patientId, testId, areaTotal, meanArea, medArea, totInt, meanInt, medInt, tumorIdx, areaTotal2, meanArea2, medArea2, totInt2, meanInt2, medInt2, tumorIdx2) values(1,"tpa.dat","patient1","test1",  225.000,  225.000,  225.000,  153.727,  153.727,  153.727,  121.063,  696.000,  696.000,  696.000,  158.259,  158.259,  158.259,  142.003);

