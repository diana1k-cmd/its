use database mias22

create table if not exists cluster(idx int, fn text, patientId text,testId text, x int, y int, dx int, dy int, intensity real);

insert into cluster(idx, fn, patientId, testId, x, y, dx, dy, area, intensity) 
values (1,"cluster1.db.txt.dat","patient1","test1",334,220,15,15,225,  153.727);

