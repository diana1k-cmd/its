use database mias22

create table if not exists zchs(idx int, fn text, patientId text,testId text, x int, intensity real);
insert into zchs(idx, fn, patientId, testId, x, intensity) values(1,"zchs.dat","patient1","test1",       44,    2.000);
insert into zchs(idx, fn, patientId, testId, x, intensity) values(2,"zchs.dat","patient1","test1",       46,    1.000);

