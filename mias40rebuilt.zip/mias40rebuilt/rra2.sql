use database mias22

create table if not exists rra2 (idx int,fn text, patientId text,testId text, result real, isSig boolean);

insert into rra1 (idx, fn, patientID, testId, result, isSig) values(0,"temp","patient1","test1",    0.000,TRUE);

