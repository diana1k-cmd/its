use database mias22

create table if not exists mchs(idx int, fn text, patientId text,testId text, x int, y int, intensity real);
insert into mchs(fn, patientId, testId, idx, x, y, intensity) values("mchs-results.dat","patient1","test1",    1,  628,  628, 2076.763);

insert into mchs(fn, patientId, testId, idx, x, y, intensity) values("mchs-results.dat","patient1","test1",    2,  625,  625, 2052.509);

insert into mchs(fn, patientId, testId, idx, x, y, intensity) values("mchs-results.dat","patient1","test1",    3,  631,  108, 1728.274);

insert into mchs(fn, patientId, testId, idx, x, y, intensity) values("mchs-results.dat","patient1","test1",    4,  628,  111, 1349.950);

insert into mchs(fn, patientId, testId, idx, x, y, intensity) values("mchs-results.dat","patient1","test1",    5,  108,  111,  986.769);

insert into mchs(fn, patientId, testId, idx, x, y, intensity) values("mchs-results.dat","patient1","test1",    6,  621,  115,  677.551);

insert into mchs(fn, patientId, testId, idx, x, y, intensity) values("mchs-results.dat","patient1","test1",    7,  621,  631,  658.659);

insert into mchs(fn, patientId, testId, idx, x, y, intensity) values("mchs-results.dat","patient1","test1",    8,  625,  104,  396.331);

insert into mchs(fn, patientId, testId, idx, x, y, intensity) values("mchs-results.dat","patient1","test1",    9,  108,  111,  235.527);

insert into mchs(fn, patientId, testId, idx, x, y, intensity) values("mchs-results.dat","patient1","test1",   10,  115,  108,  105.922);

insert into mchs(fn, patientId, testId, idx, x, y, intensity) values("mchs-results.dat","patient1","test1",   11,  111,  625,   66.568);

